﻿using DotnetCoreAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DotnetCoreAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class EmpController : ControllerBase
    {
        private readonly EmpEntites entities;

        public EmpController(EmpEntites emp )//Dependency Injection
        {
            entities = emp;
        }
        // GET: api/<EmpController>
        [HttpGet]
        public IEnumerable<Emp> Get()
        {
            return entities.Emps.ToList();
        }

        // GET api/<EmpController>/5
        [HttpGet("{id}")]
        public Emp Get(int id)
        {
            var res=(from e in entities.Emps
                    where e.ID==id
                    select e).FirstOrDefault();
            return res;
        }

        // POST api/<EmpController>
        [HttpPost]
        public void Post(Emp emp)
        {
            entities.Emps.Add(emp);
            entities.SaveChanges();
        }

        // PUT api/<EmpController>/5
        [HttpPut("{id}")]
        public ActionResult Put(int id, Emp emp)
        {
            var res = (from e in entities.Emps
                       where e.ID == id
                       select e).FirstOrDefault();
            if(res==null)
            {
                return NotFound();
            }
             else
            {
                res.Name = emp.Name;
                res.Sal = emp.Sal;
                entities.SaveChanges();

            }
            return Ok();
           
        }

        // DELETE api/<EmpController>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {

            var res = (from e in entities.Emps
                       where e.ID == id
                       select e).FirstOrDefault();

            if(res==null)
            {
                return NotFound();
            }
            else
            {
                entities.Remove(res);

                entities.SaveChanges();
            }
            return Ok();
           
        }
    }
}
