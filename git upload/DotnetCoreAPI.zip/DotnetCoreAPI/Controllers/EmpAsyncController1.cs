﻿using DotnetCoreAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DotnetCoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmpAsyncController : ControllerBase
    {
        private readonly EmpEntites entities;
        public EmpAsyncController(EmpEntites emp)
        {
            entities = emp;
        }

        [HttpGet]
        public async Task<IEnumerable<Emp>> Get()//any name you can write for get
        {
            return await entities.Emps.ToListAsync();
        }

        [HttpGet("{id}")]//url
        public async Task<Emp> Get(int id)
        {
            var res = await entities.Emps.FindAsync(id);//shortand for search by primary key only not with other attributes
            return res;
        }

        //[HttpPost]
        //public async void Post(Emp emp)
        //{
        //   await  entities.Emps.AddAsync(emp);
        //   entities.SaveChanges();
        //}

        //[HttpPost]
        //public async Task<Emp> Post(Emp emp)
        //{
        //    await entities.Emps.AddAsync(emp);
        //    entities.SaveChanges();
        //    var res = (from e in entities.Emps
        //               where e.ID == entities.Emps.Max(e => e.ID)
        //               select e).FirstOrDefault();



        //    return res;
        //}

        [HttpPost]
        public async Task<ActionResult<Emp>> Post(Emp emp)
        {
            await entities.Emps.AddAsync(emp);
            entities.SaveChanges();

            return CreatedAtAction("Get", new { id = entities.Emps.Max(e => e.ID) }, emp);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> Put(int id, Emp emp)
        {
            if (id != emp.ID)
            {
                return BadRequest();//400
            }
            var res = await entities.Emps.FindAsync(id);
            if (res == null)
            {
                return NotFound();//404
            }
            else
            {
                res.Name = emp.Name;
                res.Sal = emp.Sal;
                entities.SaveChanges();

            }
            return Ok(res);//200


        }
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {

            var res = await entities.Emps.FindAsync(id);

            if (res == null)
            {
                return NotFound();
            }

            entities.Remove(res);

            await entities.SaveChangesAsync();

            return Ok(res);

        }
    }
}
