﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DotnetCoreAPI.Models
{
    public class EmpEntites:DbContext
    {
        public EmpEntites(DbContextOptions<EmpEntites> options):base(options)
        {

        }
        public DbSet<Emp> Emps { get; set; }//Rows
    }
}
