﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 c = new Class1();
            c.Disp1();
            Console.WriteLine("Kiran");
            Console.ReadLine();
        }
    }
}
