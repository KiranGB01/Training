﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Class1
    {
        public void Disp1()
        {
            Console.WriteLine("Hello1");
        }
        internal void Disp2()
        {
            Console.WriteLine("Hello2");
        }
    }
}
