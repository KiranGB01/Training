﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class stu1Controller : ControllerBase
    {
        private readonly stuentities entities;

        public stu1Controller(stuentities stu)
        {
            entities=stu;
        }
        // GET: api/<stu1>
        [HttpGet]
        public IEnumerable<stu> Get()
        {
            return entities.Students.ToList();
        }

        // GET api/<stu1>/5
        [HttpGet("{id}")]
        public stu Get(int id)
        {
            var res = (from s in entities.Students
                       where s.id == id
                       select s).FirstOrDefault();
            return res;
        }

        // POST api/<stu1>
        [HttpPost]
        public stu Post(stu st)
        {
            entities.Students.Add(st);
            entities.SaveChanges();

            var res = (from s in entities.Students
                       where s.id == entities.Students.Max(s=>s.id)
                       select s).FirstOrDefault();
            return res;

        }

        // PUT api/<stu1>/5
        [HttpPut("{id}")]
        public void Put(int id, stu st)
        {
          

            var res = (from s in entities.Students
                       where s.id == id
                       select s).FirstOrDefault();
            
                res.name = st.name;
                res.marks = st.marks;

                entities.SaveChanges();
                 
           

        }

        // DELETE api/<stu1>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            var res = (from s in entities.Students
                       where s.id == id
                       select s).FirstOrDefault();
            entities.Students.Remove(res);
            entities.SaveChanges();

        }
    }
}
