﻿using Microsoft.EntityFrameworkCore;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Model
{
    public class stuentities:DbContext
    {
        public stuentities(DbContextOptions<stuentities> options):base(options)
        {

        }
        public DbSet<stu> Students { get; set; }
}
}
