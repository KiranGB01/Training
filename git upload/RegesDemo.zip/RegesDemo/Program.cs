﻿using System;
using System.Text.RegularExpressions;

namespace RegesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Regex r=new Regex(@"^\d?$");
            //bool res=r.IsMatch("1111111");
            //Console.WriteLine(res);
           
            Console.WriteLine("Enter the name");
            string s=Console.ReadLine();
            Regex r=new Regex(@"\w{2,}");
            bool res=r.IsMatch(s);
            Console.WriteLine(res);

            
        }
    }
}
