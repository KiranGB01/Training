﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBpractice1
{
    public partial class Form1 : Form
    {
        KiranEntities entities = new KiranEntities();
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource=entities.Students.ToList();
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_SID.Text = " ";
            txt_Name.Text = " ";
;            txt_Marks.Text = " ";
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            Student st = new Student();
            int.TryParse(txt_SID.Text, out int id);
            int.TryParse(txt_Marks.Text, out int marks);

            st.id = id;
            st.Marks = marks;
            st.Name = txt_Name.Text;

            entities.Students.Add(st);

            if (entities.SaveChanges() > 0)
                MessageBox.Show("Inserted");
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            


            int.TryParse(txt_SID.Text, out int id);

            Student res = (from s in entities.Students
                           where s.id == id
                           select s).FirstOrDefault();

            
            int.TryParse(txt_Marks.Text, out int marks);
            res.Marks = marks;
            res.Name = txt_Name.Text;

            if (entities.SaveChanges() > 0)
                MessageBox.Show("Updated");

        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            int.TryParse(txt_SID.Text, out int id);

            Student res = (from s in entities.Students
                           where s.id == id
                           select s).FirstOrDefault();

            

            if(res!=null)
            {
                txt_Name.Text = res.Name;
                txt_Marks.Text = res.Marks.ToString();
            }
            else
            {
                MessageBox.Show("Not found");
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            int.TryParse(txt_SID.Text, out int id);

            Student res = (from s in entities.Students
                           where s.id == id
                           select s).FirstOrDefault();

            

            if(res!=null)
            {
                entities.Students.Remove(res);
                
            }
            else
            {
                MessageBox.Show("Not found");
            }

            if(entities.SaveChanges()!=0)
            {
                MessageBox.Show("Deleted");
                dataGridView1.DataSource = entities.Students.ToList();
            }

            
        }
    }
}
