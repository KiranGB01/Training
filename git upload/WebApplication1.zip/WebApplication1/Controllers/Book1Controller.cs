﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Model;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication1.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class Book1Controller : ControllerBase
    {
        private readonly Book1entitites entitites;

        public Book1Controller(Book1entitites book)
        {
            entitites = book;
        }
        // GET: api/<Book1Controller>
        [HttpGet]
        public IEnumerable<Books1> Get()
        {
            return entitites.Books1s.ToList();
        }

        // GET api/<Book1Controller>/5
        [HttpGet("{id}")]
        public Books1 Get(int id)
        {
            var res = (from b in entitites.Books1s
                       where b.id == id
                       select b).FirstOrDefault();
            
            return res;
        }

        // POST api/<Book1Controller>
        [HttpPost]
        public void Post(Books1 bk)
        {
            entitites.Books1s.Add(bk);
            entitites.SaveChanges();
        }

        // PUT api/<Book1Controller>/5
        [HttpPut("{id}")]
        public ActionResult Put(int id, Books1 bk)
        {
            var res = (from b in entitites.Books1s
                       where b.id == id
                       select b).FirstOrDefault();
            if(res==null)
            {
                return NotFound();
            }
            else
            {
                res.Name = bk.Name;
                res.Price = bk.Price;
                entitites.SaveChanges();
                return Ok();
            }
        }

        // DELETE api/<Book1Controller>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var res = (from b in entitites.Books1s
                       where b.id == id
                       select b).FirstOrDefault();
            if(res==null)
            {
                return NotFound();
            }
            else
            {
                entitites.Remove(res);
                entitites.SaveChanges();
                return Ok();
            }
        }
    }
}
