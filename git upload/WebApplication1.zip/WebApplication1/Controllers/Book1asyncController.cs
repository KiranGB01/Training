﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Model;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Book1asyncController : ControllerBase
    {
        private readonly Book1entitites entitites;
        public Book1asyncController(Book1entitites book)
        {
            entitites=book;
        }

        [HttpGet]
        public async Task<IEnumerable<Books1>> get()
        {
            return await entitites.Books1s.ToListAsync();
        }
        [HttpGet("{id}")]
        public async Task<Books1> Get(int id)
        {
            var res = await entitites.Books1s.FindAsync(id);
            return res;

        }

        [HttpPost]
        public async Task<ActionResult<Books1>> Post(Books1 bk)
        {
            await entitites.Books1s.AddAsync(bk);
            entitites.SaveChanges();
            return CreatedAtAction("Get", new { id = entitites.Books1s.Max(e => e.id) }, bk);
        }
        [HttpPut("{id}")]
        public async Task<ActionResult> Put(int id,Books1 bk)
        {
            if(id!=bk.id)
            {
                return BadRequest();
            }
            var res = await entitites.Books1s.FindAsync(id);
            if(res==null)
            {
                return NotFound();
            }
            else
            {
                res.Name = bk.Name;
                res.Price = bk.Price;
                entitites.SaveChanges();
            }
            return Ok();

        }
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            var res = await entitites.Books1s.FindAsync(id);
            if(res==null)
            {
                return NotFound();
            }
           
            entitites.Books1s.Remove(res);
            await entitites.SaveChangesAsync();
            return Ok();
            
        }

    }
}
