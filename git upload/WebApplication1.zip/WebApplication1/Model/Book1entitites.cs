﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Model
{
    public class Book1entitites: DbContext
    {
        public Book1entitites(DbContextOptions<Book1entitites> options):base(options)
        {

        }
        public DbSet<Books1> Books1s { get; set; }
    }
}
