﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Model
{
    public class Bookentities: DbContext
    {
        public Bookentities(DbContextOptions<Bookentities> options):base(options)
        {

        }
        public DbSet<Book> Books { get; set; }
    }
}
