﻿using DotnetCoreAPIPractice.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DotnetCoreAPIPractice.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StuController : ControllerBase
    {
        private readonly Stuentities entities;
        public StuController(Stuentities stu)
        {
            entities = stu;
        }
        // GET: api/<StuController>
        [HttpGet]
        public IEnumerable<Student> Get()
        {
            return entities.Students.ToList();
        }

        // GET api/<StuController>/5
        [HttpGet("{id}")]
        public Student Get(int id)
        {
            var res = (from s in entities.Students
                       where s.SID == id
                       select s).FirstOrDefault();

            return res;
        }

        // POST api/<StuController>
        [HttpPost]
        public void Post(Student st)
        {
            entities.Students.Add(st);
            entities.SaveChanges();
        }

        // PUT api/<StuController>/5
        [HttpPut("{id}")]
        public ActionResult Put(int id, Student st)
        {
            var res = (from s in entities.Students
                       where s.SID == id
                       select s).FirstOrDefault();
            if(res==null)
            {
                return NotFound();
            }
            else
            {
                res.Name = st.Name;
                res.Marks = st.Marks;
                entities.SaveChanges();
            }
            return Ok();
        }

        // DELETE api/<StuController>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var res = (from s in entities.Students
                       where s.SID == id
                       select s).FirstOrDefault();
            
            if (res == null)
            {
                return NotFound();
            }
            else
            {
                entities.Remove(res);
                entities.SaveChanges();
            }
            return Ok();
        }
    }
}
