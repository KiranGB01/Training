using Microsoft.VisualStudio.TestTools.UnitTesting;
using Calculator;

namespace CalculatorTest
{
    [TestClass]
    public class TestCalculator
    {
        //1.Arrange
        readonly Calc c = new();
        [TestMethod]
        public void Test_Addtion()
        {

            //2. Act
            int res = c.Add(2, 3);
            //3. Assert
            Assert.AreEqual(5, res);

            int res1 = c.Add(-2, -3);
            Assert.AreEqual(-5, res1);

            int res2 = c.Add(-2, 3);
            Assert.AreEqual(1, res2);

            int res3 = c.Add(2, -3);
            Assert.AreEqual(-1, res3);
        }

        [TestMethod]
        public void Test_Subtraction()
        {

            //2. Act
            int res = c.Subtract(5, 3);
            //3. Assert
            Assert.AreEqual(2, res);

            Assert.AreEqual(-2, c.Subtract(-5, -3));

            Assert.AreEqual(-8, c.Subtract(-5, 3));

            Assert.AreEqual(8, c.Subtract(5, -3));
        }
        [TestMethod]
        public void Test_Multiplication()
        {

            //2. Act
            int res = c.Multiply(2, 3);
            //3. Assert
            Assert.AreEqual(6, res);

            int res1 = c.Multiply(-2, -3);
            Assert.AreEqual(6, res1);

            int res2 = c.Multiply(-2, 3);
            Assert.AreEqual(-6, res2);

            int res3 = c.Multiply(2, -3);
            Assert.AreEqual(-6, res3);
        }
        [TestMethod]
        public void Test_Division()
        {

            //2. Act
            int res = c.Divide(10, 5);
            //3. Assert
            Assert.AreEqual(2, res);

            int res1 = c.Divide(-10, -5);
            Assert.AreEqual(2, res1);

            int res2 = c.Divide(-10, 5);
            Assert.AreEqual(-2, res2);

            int res3 = c.Divide(10, -5);
            Assert.AreEqual(-2, res3);
        }
    }
}
